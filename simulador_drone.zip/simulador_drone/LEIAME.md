# Simulador de Drone PID (didático)
- `drone_sim.py`: versão Python. Instale com `pip install matplotlib` e rode com `python drone_sim.py`.
- `drone_sim.html`: versão interativa. Abra no navegador e ajuste os ganhos PID ao vivo.

O código Python foi gerado pelo DeepSeek com o Claude como orquestrador. O Claude corrigiu o sinal do PID de X.

## Simulador 3D (`drone3d.html`)
Abra no navegador do celular ou do computador (precisa de internet para carregar o three.js).
- Celular: o joystick esquerdo controla subir/descer e girar; o direito controla frente/trás e lados.
- Teclado: W/S sobe/desce, A/D gira, setas movem, T decola/pousa, C alterna a câmera.
- Tem vento com rajadas, freio automático, efeito solo, bateria (pousa sozinho abaixo de 10%) e colisões.
