# Simulador de Drone PID (didático)
- `drone_sim.py`: versão Python. Instale com `pip install matplotlib` e rode com `python drone_sim.py`.
- `drone_sim.html`: versão interativa. Abra no navegador e ajuste os ganhos PID ao vivo.

O código Python foi gerado pelo DeepSeek com o Claude como orquestrador. O Claude corrigiu o sinal do PID de X.
