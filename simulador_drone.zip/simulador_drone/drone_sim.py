#!/usr/bin/env python3
"""
Simulador didático de drone em 2D (X vertical? Não: X horizontal, Y altitude).
Modelo simplificado com 2 rotores, atitude (ângulo de rolagem), PID para altitude
e posição X, integração de Euler com dt fixo, missão por waypoints e gráficos.

Conceitos físicos:
- Massa (m): resistência à aceleração (F = m*a).
- Gravidade (g): aceleração puxando o drone para baixo.
- Empuxo dos rotores: força perpendicular ao eixo do drone, gerada por cada rotor.
- Arrasto: força oposta à velocidade, proporcional à velocidade (modelo linear).
- Inércia rotacional (I): resistência à aceleração angular (torque = I*alpha).
- Torque: diferença de empuxo entre rotores gera rotação.

Conceitos de controle:
- PID: Proporcional (erro atual), Integral (soma de erros passados) e Derivativo
  (variação do erro). Usado aqui para altitude (thrust total) e posição X (ângulo).
- Waypoints: alvos sequenciais; o controlador converge para cada um.
"""
import math
import matplotlib.pyplot as plt

class Drone:
    def __init__(self):
        # Parâmetros físicos
        self.m = 1.0            # massa [kg]
        self.g = 9.81           # gravidade [m/s^2]
        self.I = 0.05           # momento de inércia rotacional [kg*m^2]
        self.b = 0.1            # coef. de arrasto translacional [N*s/m]
        self.b_rot = 0.05       # coef. de arrasto rotacional [N*m*s/rad]
        self.L = 0.25           # braço (distância do centro ao rotor) [m]
        # Estado: [x, xdot, y, ydot, theta, thetadot]
        self.state = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
        # Comandos (entradas do controlador): empuxo total e momento
        self.u_thrust = 0.0     # empuxo total desejado [N]
        self.u_torque = 0.0     # torque desejado [N*m]
        # Limites dos rotores (cada rotor gera de 0 a Fmax)
        self.Fmax = 10.0        # empuxo máximo por rotor [N]

    def apply_rotors(self):
        """Converte empuxo total e torque em empuxo individual dos rotores.
        Rotor esquerdo (1) e direito (2) separados por 2L no eixo do corpo.
        F_total = F1 + F2 ; torque = (F2 - F1)*L  (rotação positiva = anti-horário)
        """
        F1 = (self.u_thrust - self.u_torque / self.L) / 2.0
        F2 = (self.u_thrust + self.u_torque / self.L) / 2.0
        return max(0.0, min(F1, self.Fmax)), max(0.0, min(F2, self.Fmax))

    def dynamics(self, dt):
        """Atualiza o estado via Euler explícito com passo dt fixo."""
        x, vx, y, vy, th, w = self.state
        F1, F2 = self.apply_rotors()
        F = F1 + F2                       # empuxo total no eixo do corpo
        tau = (F2 - F1) * self.L          # torque resultante
        # Forças no referencial do corpo rotacionado por theta
        # Empuxo aponta na direção "para cima" do corpo: (-sin th, cos th)
        ax = (F * (-math.sin(th)) - self.b * vx) / self.m
        ay = (F * math.cos(th) - self.m * self.g - self.b * vy) / self.m
        # Dinâmica rotacional
        alpha = (tau - self.b_rot * w) / self.I
        # Integração de Euler
        x  += vx * dt
        vx += ax * dt
        y  += vy * dt
        vy += ay * dt
        th += w  * dt
        w  += alpha * dt
        self.state = [x, vx, y, vy, th, w]

class PID:
    """Controlador PID com anti-windup simples e limites de saída."""
    def __init__(self, kp, ki, kd, out_min, out_max):
        self.kp, self.ki, self.kd = kp, ki, kd
        self.out_min, self.out_max = out_min, out_max
        self.integ = 0.0
        self.prev_err = 0.0

    def update(self, setpoint, measured, dt):
        err = setpoint - measured
        self.integ += err * dt
        deriv = (err - self.prev_err) / dt if dt > 0 else 0.0
        self.prev_err = err
        out = self.kp * err + self.ki * self.integ + self.kd * deriv
        # Anti-windup: limita integral se saturar
        if out > self.out_max:
            out = self.out_max
            self.integ -= err * dt
        elif out < self.out_min:
            out = self.out_min
            self.integ -= err * dt
        return out

def run_simulation():
    drone = Drone()
    dt = 0.01       # passo fixo [s]
    T = 25.0        # duração da simulação [s]
    n_steps = int(T / dt)

    # Controladores: altitude -> empuxo total ; X -> ângulo desejado
    pid_alt = PID(kp=8.0, ki=1.0, kd=4.0, out_min=0.0, out_max=2*drone.Fmax)
    pid_x   = PID(kp=0.8, ki=0.05, kd=0.6, out_min=-0.3, out_max=0.3)  # saída = theta_ref
    pid_att = PID(kp=6.0, ki=0.5, kd=1.0, out_min=-1.0, out_max=1.0)   # theta_ref -> torque

    # Missão por waypoints (x, y). Inclui decolagem, deslocamento e pouso lógico.
    waypoints = [(0.0, 2.0), (3.0, 2.0), (3.0, 1.0), (0.0, 0.5)]
    wp_idx = 0
    wp_tolerance = 0.15
    wp_hold_time = 0.5
    hold_counter = 0.0

    # Armazenamento para plots
    log = {"t": [], "x": [], "y": [], "theta": [], "thrust": []}

    for k in range(n_steps):
        t = k * dt
        tx, ty = waypoints[wp_idx]
        x, vx, y, vy, th, w = drone.state

        # Controle de altitude: erro em y -> empuxo total
        thrust_cmd = pid_alt.update(ty, y, dt)

        # Controle de posição X: erro em x -> ângulo desejado (inclina para mover)
        # Empuxo aponta para (-sin th): inclinar +theta move para -X, por isso o sinal negativo
        theta_ref = -pid_x.update(tx, x, dt)

        # Controle de atitude: segue ângulo desejado -> torque
        torque_cmd = pid_att.update(theta_ref, th, dt)

        drone.u_thrust = thrust_cmd
        drone.u_torque = torque_cmd

        drone.dynamics(dt)

        # Verifica se atingiu waypoint (posição) por tempo de espera
        if math.hypot(tx - x, ty - y) < wp_tolerance:
            hold_counter += dt
            if hold_counter >= wp_hold_time and wp_idx < len(waypoints) - 1:
                wp_idx += 1
                hold_counter = 0.0

        # Log
        log["t"].append(t)
        log["x"].append(drone.state[0])
        log["y"].append(drone.state[2])
        log["theta"].append(drone.state[4])
        log["thrust"].append(drone.u_thrust)

    return log, waypoints

def plot_results(log, waypoints):
    fig, axes = plt.subplots(2, 2, figsize=(11, 8))
    t = log["t"]

    axes[0, 0].plot(t, log["y"], label="altitude")
    axes[0, 0].plot(t, log["x"], label="posição X", linestyle="--")
    axes[0, 0].set_title("Altitude e Posição X vs Tempo")
    axes[0, 0].set_xlabel("tempo [s]"); axes[0, 0].set_ylabel("[m]")
    axes[0, 0].grid(True); axes[0, 0].legend()

    axes[0, 1].plot(t, log["theta"], color="purple")
    axes[0, 1].set_title("Ângulo (Roll) vs Tempo")
    axes[0, 1].set_xlabel("tempo [s]"); axes[0, 1].set_ylabel("[rad]")
    axes[0, 1].grid(True)

    axes[1, 0].plot(t, log["thrust"], color="orange")
    axes[1, 0].set_title("Empuxo Total vs Tempo")
    axes[1, 0].set_xlabel("tempo [s]"); axes[1, 0].set_ylabel("[N]")
    axes[1, 0].grid(True)

    axes[1, 1].plot(log["x"], log["y"], label="trajetória")
    wpx = [w[0] for w in waypoints]; wpy = [w[1] for w in waypoints]
    axes[1, 1].scatter(wpx, wpy, marker="*", s=150, c="red", label="waypoints")
    axes[1, 1].set_title("Trajetória no Plano X-Y")
    axes[1, 1].set_xlabel("X [m]"); axes[1, 1].set_ylabel("Y / altitude [m]")
    axes[1, 1].grid(True); axes[1, 1].legend()

    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    log, waypoints = run_simulation()
    plot_results(log, waypoints)
